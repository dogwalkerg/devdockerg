<?php

namespace App\Models;

class RadiusBan extends Model
{
    protected $connection = 'default';
    protected $table = 'radius_ban';
}
