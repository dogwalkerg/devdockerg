<?php

namespace App\Models;

class RadiusRadUserGroup extends Model
{
    protected $connection = "radius";
    protected $table = "radusergroup";
}
